// ServiceAppointment - a service booked for a customer, like a basic vet visit, and whether they paid for it yet.
// Part 2 adds the csv pieces so the booked services carry over to the next day.
// Carl Service
// CSC-251 - Farm Store Part 2
// September 24, 2026

public class ServiceAppointment {
    private String description;
    private String date;
    private double fee;
    private boolean isPaid;

    public ServiceAppointment(String description, String date, double fee) {
        this.description = description;
        this.date = date;
        this.fee = fee;
        this.isPaid = false;
    }

    public String getDescription() { return description; }
    public double getFee() { return fee; }
    public boolean isPaid() { return isPaid; }

    // flips the paid flag once the customer settles up
    public void markPaid() {
        this.isPaid = true;
    }

    public String toCSV() {
        return description + "," + date + "," + fee + "," + isPaid;
    }

    // the paid flag is not a constructor argument, the constructor always starts a service off unpaid, so it has to get set after the object is built by calling markPaid
    public static ServiceAppointment fromCSV(String line) {
        String[] parts = line.split(",");

        String description = parts[0];
        String date = parts[1];
        double fee = Double.parseDouble(parts[2]);
        boolean paid = Boolean.parseBoolean(parts[3]);

        ServiceAppointment service = new ServiceAppointment(description, date, fee);

        if (paid) {
            service.markPaid();
        }

        return service;
    }

    @Override
    public String toString() {
        String status = isPaid ? "Paid" : "Unpaid";
        return date + " - " + description + " ($" + String.format("%.2f", fee) + ") - " + status;
    }
}
