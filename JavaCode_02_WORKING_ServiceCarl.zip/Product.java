// Product - a single item the store sells.
// Part 2 adds the CSV pieces so a product can be written out to a line of text and built back up again when the program starts.
// Carl Service
// CSC-251 - Farm Store Part 2
// September 24, 2026

public class Product {
    private String name;
    private double price;
    private int quantity;

    public Product(String name, double price, int quantity) {
        this.name = name;
        this.price = price;
        this.quantity = quantity;
    }

    public String getName() { return name; }
    public double getPrice() { return price; }
    public int getQuantity() { return quantity; }

    // take the sold amount back off the stock
    public void sell(int amount) {
        if (amount <= quantity) {
            quantity -= amount;
        }
    }

    // turns this product into one comma seperated line for the csv file.
    // the order here has to match what readProducts is expecting when it splits the line back apart, otherwise the price and the quantity end up swapped around
    public String toCSV() {
        return name + "," + price + "," + quantity;
    }

    public static Product fromCSV(String line) {
        String[] parts = line.split(",");

        String name = parts[0];
        double price = Double.parseDouble(parts[1]);
        int quantity = Integer.parseInt(parts[2]);

        return new Product(name, price, quantity);
    }

    @Override
    public String toString() {
        return name + " ($" + String.format("%.2f", price) + ") - " + quantity + " in stock";
    }
}
