// Animal - an animal for sale. The breeder flag is how the specialty resales get tracked seperately from the ones bred on the farm.
// Part 2 adds toCSV and fromCSV so the animals can be saved and reloaded.
// Carl Service
// CSC-251 - Farm Store Part 2
// September 24, 2026

public class Animal {
    private String species;
    private double price;
    private boolean isBreederSourced;

    public Animal(String species, double price, boolean isBreederSourced) {
        this.species = species;
        this.price = price;
        this.isBreederSourced = isBreederSourced;
    }

    // getters so the other classes can read these
    public String getSpecies() { return species; }
    public double getPrice() { return price; }
    public boolean isBreederSourced() { return isBreederSourced; }

    // one csv line for this animal. the boolean writes itself out as true or false on its own so it does not need anything done to it
    public String toCSV() {
        return species + "," + price + "," + isBreederSourced;
    }

    public static Animal fromCSV(String line) {
        String[] parts = line.split(",");

        String species = parts[0];
        double price = Double.parseDouble(parts[1]);

        // Boolean.parseBoolean reads the word true or false back off the line.
        // anything that is not the word true comes back false which is fine here because the file only ever holds one or the other
        boolean breeder = Boolean.parseBoolean(parts[2]);

        return new Animal(species, price, breeder);
    }

    @Override
    public String toString() {
        String source = isBreederSourced ? " (Specialty Resale)" : " (Farm Bred)";
        return species + source + " - $" + String.format("%.2f", price);
    }
}
