// Carl Service
// CSC-251 - Farm Store Part 2
// September 24, 2026

import javax.swing.JOptionPane;
import java.util.ArrayList;
import java.io.PrintWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class FarmStore {
    private ArrayList<Product> products = new ArrayList<>();
    private ArrayList<Animal> animals = new ArrayList<>();
    private ArrayList<ServiceAppointment> services = new ArrayList<>();
    private double dailyTotal = 0.0;

    private static final String PRODUCT_FILE = "products.csv";
    private static final String ANIMAL_FILE = "animals.csv";
    private static final String SERVICE_FILE = "services.csv";

    public FarmStore() {
        loadProducts();
        loadAnimals();
        loadServices();

        if (products.isEmpty() && animals.isEmpty()) {
            loadStartingStock();
            saveProducts();
            saveAnimals();
        }
    }

    private void loadStartingStock() {
        products.add(new Product("Duck Feed", 15.99, 50));
        products.add(new Product("Straw Bale", 8.50, 100));
        products.add(new Product("Chicken Feeder", 25.00, 10));
        animals.add(new Animal("Duck", 12.00, false));
        animals.add(new Animal("Chicken", 8.00, false));
        animals.add(new Animal("Hamster", 15.00, true));
    }

    private void loadProducts() {
        File file = new File(PRODUCT_FILE);
        if (!file.exists()) {
            return;
        }
        try {
            Scanner reader = new Scanner(file);
            while (reader.hasNextLine()) {
                String line = reader.nextLine().trim();
                if (!line.isEmpty()) {
                    products.add(Product.fromCSV(line));
                }
            }
            reader.close();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Could not read the products file.");
        }
    }

    private void loadAnimals() {
        File file = new File(ANIMAL_FILE);
        if (!file.exists()) {
            return;
        }
        try {
            Scanner reader = new Scanner(file);
            while (reader.hasNextLine()) {
                String line = reader.nextLine().trim();
                if (!line.isEmpty()) {
                    animals.add(Animal.fromCSV(line));
                }
            }
            reader.close();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Could not read the animals file.");
        }
    }

    private void loadServices() {
        File file = new File(SERVICE_FILE);
        if (!file.exists()) {
            return;
        }
        try {
            Scanner reader = new Scanner(file);
            while (reader.hasNextLine()) {
                String line = reader.nextLine().trim();
                if (!line.isEmpty()) {
                    services.add(ServiceAppointment.fromCSV(line));
                }
            }
            reader.close();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Could not read the services file.");
        }
    }

    private void saveProducts() {
        try {
            PrintWriter writer = new PrintWriter(new FileWriter(PRODUCT_FILE, false));
            for (Product p : products) {
                writer.println(p.toCSV());
            }
            writer.close();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Could not save the products file.");
        }
    }

    private void saveAnimals() {
        try {
            PrintWriter writer = new PrintWriter(new FileWriter(ANIMAL_FILE, false));
            for (Animal a : animals) {
                writer.println(a.toCSV());
            }
            writer.close();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Could not save the animals file.");
        }
    }

    private void saveServices() {
        try {
            PrintWriter writer = new PrintWriter(new FileWriter(SERVICE_FILE, false));
            for (ServiceAppointment s : services) {
                writer.println(s.toCSV());
            }
            writer.close();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Could not save the services file.");
        }
    }

    private void saveEverything() {
        saveProducts();
        saveAnimals();
        saveServices();
    }

    public void start() {
        boolean running = true;
        while (running) {
            String[] options = {
                "Sell Store Item",
                "Record Animal Sale",
                "Record Specialty Resale",
                "Book Service",
                "View Summary",
                "Exit"
            };
            int choice = JOptionPane.showOptionDialog(null,
                "Welcome to the Farm Store System\nTotal Sales Today: $" + String.format("%.2f", dailyTotal),
                "Farm Store Menu",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.INFORMATION_MESSAGE,
                null, options, options[0]);

            switch (choice) {
                case 0: sellItem(); break;
                case 1: recordAnimalSale(false); break;
                case 2: recordAnimalSale(true); break;
                case 3: bookService(); break;
                case 4: viewSummary(); break;
                case 5:
                case JOptionPane.CLOSED_OPTION:
                    saveEverything();
                    JOptionPane.showMessageDialog(null, "Data saved. Goodbye.");
                    running = false;
                    break;
            }
        }
    }

    private void sellItem() {
        StringBuilder sb = new StringBuilder("Select an item to sell (Enter number):\n");
        for (int i = 0; i < products.size(); i++) {
            sb.append(i + 1).append(". ").append(products.get(i).toString()).append("\n");
        }
        String input = JOptionPane.showInputDialog(null, sb.toString());
        if (input != null && !input.trim().isEmpty()) {
            try {
                int index = Integer.parseInt(input.trim()) - 1;
                if (index >= 0 && index < products.size()) {
                    Product p = products.get(index);
                    if (p.getQuantity() > 0) {
                        p.sell(1);
                        dailyTotal += p.getPrice();
                        saveProducts();
                        JOptionPane.showMessageDialog(null, "Sold 1 " + p.getName() + " for $" + String.format("%.2f", p.getPrice()));
                    } else {
                        JOptionPane.showMessageDialog(null, "Out of stock.");
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Invalid selection.");
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Please enter a valid number.");
            }
        }
    }

    private void recordAnimalSale(boolean isSpecialty) {
        StringBuilder sb = new StringBuilder("Select an animal to sell (Enter number):\n");
        ArrayList<Animal> filtered = new ArrayList<>();
        for (Animal a : animals) {
            if (a.isBreederSourced() == isSpecialty) {
                filtered.add(a);
            }
        }
        if (filtered.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No animals of this type available.");
            return;
        }
        for (int i = 0; i < filtered.size(); i++) {
            sb.append(i + 1).append(". ").append(filtered.get(i).toString()).append("\n");
        }
        String input = JOptionPane.showInputDialog(null, sb.toString());
        if (input != null && !input.trim().isEmpty()) {
            try {
                int index = Integer.parseInt(input.trim()) - 1;
                if (index >= 0 && index < filtered.size()) {
                    Animal a = filtered.get(index);
                    dailyTotal += a.getPrice();
                    animals.remove(a);
                    saveAnimals();
                    JOptionPane.showMessageDialog(null, "Sold " + a.getSpecies() + " for $" + String.format("%.2f", a.getPrice()));
                } else {
                    JOptionPane.showMessageDialog(null, "Invalid selection.");
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Please enter a valid number.");
            }
        }
    }

    private void bookService() {
        String desc = JOptionPane.showInputDialog("Enter service description (e.g., Tractor Repair):");
        if (desc == null || desc.trim().isEmpty()) return;
        String date = JOptionPane.showInputDialog("Enter date (e.g., Oct 1):");
        if (date == null || date.trim().isEmpty()) return;
        String feeStr = JOptionPane.showInputDialog("Enter fee amount:");
        if (feeStr == null || feeStr.trim().isEmpty()) return;
        try {
            double fee = Double.parseDouble(feeStr.trim());
            ServiceAppointment service = new ServiceAppointment(desc, date, fee);
            int payNow = JOptionPane.showConfirmDialog(null, "Is the service paid now?", "Payment", JOptionPane.YES_NO_OPTION);
            if (payNow == JOptionPane.YES_OPTION) {
                service.markPaid();
                dailyTotal += fee;
            }
            services.add(service);
            saveServices();
            JOptionPane.showMessageDialog(null, "Service booked successfully.");
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Invalid fee entered. Try again.");
        }
    }

    private void viewSummary() {
        StringBuilder sb = new StringBuilder("--- Day Summary ---\n");
        sb.append("Total Sales: $").append(String.format("%.2f", dailyTotal)).append("\n\n");
        sb.append("Items in Stock:\n");
        if (products.isEmpty()) {
            sb.append("None\n");
        } else {
            for (Product p : products) {
                sb.append(p.toString()).append("\n");
            }
        }
        sb.append("\nServices Booked:\n");
        if (services.isEmpty()) {
            sb.append("None\n");
        } else {
            for (ServiceAppointment s : services) {
                sb.append(s.toString()).append("\n");
            }
        }
        JOptionPane.showMessageDialog(null, sb.toString());
    }

    public static void main(String[] args) {
        FarmStore store = new FarmStore();
        store.start();
    }
}
