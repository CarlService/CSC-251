// ServiceAppointment - a service booked for a customer, like a basic vet visit, and whether they paid for it yet.
// Carl Service
// CSC-251 - Farm Store Part 2
// September 24, 2026

public class ServiceAppointment {
    private String description;
    private String date;
    private double fee;
    private boolean isPaid;

    public ServiceAppointment(String description, String date, double fee) {
        this.description = description;
        this.date = date;
        this.fee = fee;
        this.isPaid = false;
    }

    public String getDescription() { return description; }
    public double getFee() { return fee; }
    public boolean isPaid() { return isPaid; }

    public void markPaid() {
        this.isPaid = true;
    }

    public String toCSV() {
        return description + "," + date + "," + fee + "," + isPaid;
    }

    public static ServiceAppointment fromCSV(String line) {
        String[] parts = line.split(",");
        ServiceAppointment service = new ServiceAppointment(parts[0], parts[1], Double.parseDouble(parts[2]));

        if (Boolean.parseBoolean(parts[3])) {
            service.markPaid();
        }

        return service;
    }

    @Override
    public String toString() {
        String status = isPaid ? "Paid" : "Unpaid";
        return date + " - " + description + " ($" + String.format("%.2f", fee) + ") - " + status;
    }
}
