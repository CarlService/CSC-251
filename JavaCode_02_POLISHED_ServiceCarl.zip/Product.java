// Product - a single item the store sells.
// Carl Service
// CSC-251 M3 - Farm Store Part 2
// September 24, 2026

public class Product {
    private String name;
    private double price;
    private int quantity;

    public Product(String name, double price, int quantity) {
        this.name = name;
        this.price = price;
        this.quantity = quantity;
    }

    public String getName() { return name; }
    public double getPrice() { return price; }
    public int getQuantity() { return quantity; }

    public void sell(int amount) {
        if (amount <= quantity) {
            quantity -= amount;
        }
    }

    public String toCSV() {
        return name + "," + price + "," + quantity;
    }

    public static Product fromCSV(String line) {
        String[] parts = line.split(",");
        return new Product(parts[0], Double.parseDouble(parts[1]), Integer.parseInt(parts[2]));
    }

    @Override
    public String toString() {
        return name + " ($" + String.format("%.2f", price) + ") - " + quantity + " in stock";
    }
}
