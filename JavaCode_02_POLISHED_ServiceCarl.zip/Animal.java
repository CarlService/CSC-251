// Carl Service
// CSC-251 M3 - Farm Store Part 2
// September 24, 2026

public class Animal {
    private String species;
    private double price;
    private boolean isBreederSourced;

    public Animal(String species, double price, boolean isBreederSourced) {
        this.species = species;
        this.price = price;
        this.isBreederSourced = isBreederSourced;
    }

    public String getSpecies() { return species; }
    public double getPrice() { return price; }
    public boolean isBreederSourced() { return isBreederSourced; }

    public String toCSV() {
        return species + "," + price + "," + isBreederSourced;
    }

    public static Animal fromCSV(String line) {
        String[] parts = line.split(",");
        return new Animal(parts[0], Double.parseDouble(parts[1]), Boolean.parseBoolean(parts[2]));
    }

    @Override
    public String toString() {
        String source = isBreederSourced ? " (Specialty Resale)" : " (Farm Bred)";
        return species + source + " - $" + String.format("%.2f", price);
    }
}
